package com.crd.plugin;

import com.crd.compliance.plugin.CompliancePlugin;


public class CRDCompilancePlugin implements CompliancePlugin {

	@Override
	public void beforePreTrade(long runId, long basketId) throws Exception {
		
		ComplianceObject cplObj = new ComplianceObject(runId, basketId, "BEFORE_PRE_TRADE", "COMPLIANCE");
		String uri = "http://localhost:52076/OMVCRDService.svc/Compliance";
		ServiceConnector connector = new ServiceConnector(cplObj);
		ComplianceObjectResponse response = connector.sendRequest(uri);
	}

}
