package com.crd.plugin;

public class ComplianceObjectResponse {
	private String status;
	private String message;
	private ComplianceObject complianceObject;
	
	ComplianceObjectResponse(ComplianceObject complianceObject){
		this.status = "Status not set";
		this.message = "No message available";
		this.complianceObject = complianceObject;
	}
	ComplianceObjectResponse(String status, String message, ComplianceObject complianceObject){
		this.status = status;
		this.message = message;
		this.complianceObject = complianceObject;
	}

	public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		this.status = status;
	}
	public String getmessage() {
		return message;
	}
	public void setmessage(String message) {
		this.message = message;
	}
	public ComplianceObject getcomplianceObject() {
		return complianceObject;
	}
	public void setcomplianceObject(ComplianceObject complianceObject) {
		this.complianceObject = complianceObject;
	}	
}
