package com.crd.plugin;
import java.io.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



public class ServiceConnector {
	private ComplianceObject cplObj;

	ServiceConnector(ComplianceObject cplObj){
		this.cplObj = cplObj;
	}
	
	public ComplianceObjectResponse sendRequest(String uri) throws Exception{
		ComplianceObjectResponse runResult;
		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.create();
		
		String cplJson = gson.toJson(this.cplObj);
		URL url = new URL(uri);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/json");

		String input = cplJson;

		OutputStream os = conn.getOutputStream();
		os.write(input.getBytes());
		os.flush();

		if (conn.getResponseCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
				+ conn.getResponseCode());
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

		String output;
		String response = "";
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
			response = response + output;
			System.out.println(output);
		}
		runResult = gson.fromJson(response, ComplianceObjectResponse.class);
		runResult.setcomplianceObject(this.cplObj);
		conn.disconnect();
		

		return runResult;
	}
}
