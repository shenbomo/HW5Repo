package com.crd.plugin;

public class ComplianceObject {
	private long runId;
	private long basketId;
	private String serviceObjectType;
	private String workflow;
	//Available default workflows:
	//BEFOREPRETRADE || BEFOREPOSTTRADE || AFTERPRETRADE || AFTERPOSTTRADE || BEFOREINTRADE || AFTERINTRADE
	ComplianceObject(){
		this.runId = 0;
		this.basketId = 0;
		this.workflow = "BEFORE_PRE_TRADE";
		this.serviceObjectType = "COMPLIANCE";
	}

	ComplianceObject(long runId, long basketId, String workflow, String serviceObjectType){
		this.runId = runId;
		this.basketId = basketId;
		this.workflow = workflow;
		this.serviceObjectType = serviceObjectType;
	}
	public long getRunId(){
		return runId;
	}
	public void setRunId(long runId){
		this.runId = runId;
	}
	public long getBasketId(){
		return basketId;
	}
	public void setBasketId(long basketId){
		this.basketId = basketId;
	}
	public String getWorkflow(){
		return workflow;
	}
	public void setWorkflow(String workflow){
		this.workflow = workflow;
	}
	public String getServiceObjectType(){
		return serviceObjectType;
	}
	public void setServiceObjectType(String serviceObjectType) {
		this.serviceObjectType = serviceObjectType;
	}
}
