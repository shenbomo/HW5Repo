﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using log4net;

namespace CRDPluginService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    /// <summary>
    /// Implementation of the endpoint methods
    /// </summary>
    public class OMVCRDService : IOMVCRDService
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public String TestGet()
        {
            return "Test GET";
        }
        public String TestPost(String body)
        {
            return "Test POST, request body is: " + body;
        }
        /// <summary>
        /// For help information of the service API
        /// </summary>
        /// <returns>The detail information of the API and response</returns>
        public Conventions GetServiceConventions()
        {
            return new Conventions();
        }
        /// <summary>
        /// Method for executing workflows of the Compliance Plugin requests
        /// Calling the Execution.ExecuteCompliance(...) to handle the workflow execution
        /// </summary>
        /// <param name="co">ComplianceObject</param>
        /// <returns>ComplianceObjectResponse</returns>
        public ComplianceObjectResponse ExecuteComplianceWorkflow(ComplianceObject co)
        {
            log.Info("ComplianceObject received from the client. Trying to execute compliance workflow...");
            ComplianceObjectResponse cor = new ComplianceObjectResponse();
            if (co.serviceObjectType == "COMPLIANCE")
            {
                log.Info("The ServiceObjectType matches 'COMPLIANCE', compliance workflow execution begins...");
                cor = Execution.ExecuteCompliance(co);
            }
            else
            {
                log.Error("The ServiceObjectType is incorrect, workflow execution failed.");
                cor.status = "FAILURE";
                cor.message = "The ServiceObjectType is incorrect, this endpoint of the service only takes in a ComplianceObject. "
                              + "Please try setting ServiceObjectType to ''COMPLIANCE'' instead!"; 
            }
            return cor;       
        }
        public ServiceObjectResponse ExecuteAllocationWorkflow(ComplianceObject co)
        {
            return Execution.ExecuteAllocation(co);
        }
        public ServiceObjectResponse ExecutePlacementWorkflow(ComplianceObject co)
        {
            return Execution.ExecutePlacement(co);
        }
    }
}
