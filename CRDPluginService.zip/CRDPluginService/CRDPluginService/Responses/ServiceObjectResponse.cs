﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace CRDPluginService
{
    /// <summary>
    /// ServiceObjectResponse is the parent class defining the basic information needed to construct the response per client's request
    /// This class can be extended/derived to hold more information based on the ServiceObjectType of the ServiceObject, ComplianceObjectResponse is an example
    /// </summary>
    [DataContract]
    public class ServiceObjectResponse
    {
        /// <summary>
        /// Status will be set to the result status after the execution of the work-flow
        /// Available values will be: "SUCCESS","FAILURE","WARNING"
        /// Client will throw exceptions based on this value
        /// </summary>
        [DataMember]
        public String status { get; set; }
        /// <summary>
        /// Message will contain the detail description of the result after the execution of the work-flow
        /// Client will show this message to the user if needed
        /// </summary>
        [DataMember]
        public String message { get; set; }

    }
}