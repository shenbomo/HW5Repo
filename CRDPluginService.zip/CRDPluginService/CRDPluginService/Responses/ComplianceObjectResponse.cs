﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace CRDPluginService
{
    /// <summary>
    /// This class is extended/derived from ServiceObjectResponse
    /// which holds the actual ComplianceObject passed in from the client
    /// </summary>
    [DataContract]
    public class ComplianceObjectResponse : ServiceObjectResponse
    {
        /// <summary>
        /// The ComplianceObject which contains the information in the client request to refer back if needed
        /// </summary>
        [DataMember]
        public ComplianceObject serviceObject { get; set; }
    }
}