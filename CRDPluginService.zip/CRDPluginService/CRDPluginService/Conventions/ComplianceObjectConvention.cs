﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace CRDPluginService
{
    /// <summary>
    /// Detail example of the ComplianceObject
    /// </summary>
    [DataContract]
    public class ComplianceObjectConvention
    {
        /// <summary>
        /// serviceObjectType
        /// </summary>
        [DataMember]
        public String serviceObjectType = "COMPLIANCE";
        /// <summary>
        /// basketId
        /// </summary>
        [DataMember]
        public String basketId = "[VALUE: Integer]";
        /// <summary>
        /// runId
        /// </summary>
        [DataMember]
        public String runId = "[VALUE: Integer]";
        /// <summary>
        /// workflow
        /// </summary>
        [DataMember]
        public String workflow = "BEFORE_PRE_TRADE || BEFORE_POST_TRADE || AFTER_PRE_TRADE || AFTER_POST_TRADE || BEFORE_IN_TRADE || AFTER_IN_TRADE";

    }
}