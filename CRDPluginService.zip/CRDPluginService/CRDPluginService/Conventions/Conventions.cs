﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace CRDPluginService
{
    /// <summary>
    /// This is an API help information for the client development
    /// </summary>
    [DataContract]
    public class Conventions
    {
        /// <summary>
        /// This is an example of the ComplianceObject JSON format which the client should build in the request body
        /// </summary>
        [DataMember]
        public ComplianceObjectConvention complianceObjectConvention = new ComplianceObjectConvention();
        /// <summary>
        /// This is an interpretation of the response convention
        /// </summary>
        [DataMember]
        public ResponseConvention responseConvention = new ResponseConvention();

    }
}