﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace CRDPluginService
{
    /// <summary>
    /// Detail information about the what the Response should look like
    /// </summary>
    [DataContract]
    public class ResponseConvention
    {
        /// <summary>
        /// message
        /// </summary>
        [DataMember]
        public String message = "[A customized message to the user]";
        /// <summary>
        /// status
        /// </summary>
        [DataMember]
        public String status = "WARNING || FAILURE || SUCCESS";
    }
}