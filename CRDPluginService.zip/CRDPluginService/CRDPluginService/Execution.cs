﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace CRDPluginService
{
    /// <summary>
    /// This static class directs the request call to the specific workflow based on the information in the request body
    /// aka the ServiceObject which client has passed in
    /// 
    /// Each endpoint(service) provided will have a matching method to handle the execution of that ServiceObject
    /// Based on the execution result, a response will be generated to be sent back to the client
    /// </summary>
    public static class Execution
    {
        /// <summary>
        /// Execution handler for ComplianceService using the information provided in the Compliance ServiceObject (ComplianceObject)
        /// </summary>
        /// <param name="complianceObject">ComplianceObject</param>
        /// <returns>ComplianceObjectResponse</returns>
        public static ComplianceObjectResponse ExecuteCompliance(ComplianceObject complianceObject)
        {
            var msg = String.Empty;

            ComplianceObjectResponse response = new ComplianceObjectResponse();
            #region Switch for different workflows
            switch (complianceObject.workflow)
            {
                // each case could implement whatever business logic needed
                case "BEFORE_PRE_TRADE":
                    break;
                case "BEFORE_POST_TRADE":
                    break;
                case "AFTER_PRE_TRADE":
                    break;
                case "AFTER_POST_TRADE":
                    break;
                case "BEFORE_IN_TRADE":
                    break;
                case "AFTER_IN_TRADE":
                    break;
                default:
                    response.status = "FAILURE";
                    response.message = "The workflow specified from the request is incorrect, please try one of the following:"
                                  + " BEFORE_PRE_TRADE ||" 
                                  + " BEFORE_POST_TRADE ||" 
                                  + " AFTER_PRE_TRADE ||" 
                                  + " AFTER_POST_TRADE ||" 
                                  + " BEFORE_IN_TRADE ||" 
                                  + " AFTER_IN_TRADE ||";
                    goto CASE_INVALID_WORKFLOW;
            }
            #endregion

            // Setting the Response info only when the workflow is valid
            //cor.status = cwf.status;
            //cor.message = cwf.message;
            response.status = "Test Only";
            response.message = "No workflow has been executed since none implemented.";
            response.serviceObject = complianceObject;
        // if the workflow is not valid, we skip the normal settings of the Response info
        CASE_INVALID_WORKFLOW:
            return response;
        }
        public static ServiceObjectResponse ExecuteAllocation(ComplianceObject co)
        {
            // ExecuteAllocation certain workflow based on ComplianceObject
            ComplianceObjectResponse cor = new ComplianceObjectResponse();
            cor.status = "No Errors";
            cor.message = "Testing Allocation Workflow Execution";
            cor.serviceObject = co;
            return cor;
        }
        public static ServiceObjectResponse ExecutePlacement(ComplianceObject co)
        {
            // ExecutePlacement certain workflow based on ComplianceObject
            ComplianceObjectResponse cor = new ComplianceObjectResponse();
            cor.status = "No Errors";
            cor.message = "Testing Placement Workflow Execution";
            cor.serviceObject = co;
            return cor;
        }
    }
}