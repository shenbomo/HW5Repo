﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CRDPluginService
{
    /// <summary>
    /// Interface for the services endpoint methods based on the URI in the http request
    /// Endpoint will be based on the CRD Plugin entry point
    /// </summary>
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IOMVCRDService" in both code and config file together.
    [ServiceContract]
    public interface IOMVCRDService
    {
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "Test/")]
        String TestGet();
        [OperationContract]
        [WebInvoke(Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "Test/")]
        String TestPost(String body);
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "Conventions/")]
        Conventions GetServiceConventions();

        // One each endpoint for calling the service at different entry point
        // and executing certain workflow based on the workflow definition
        // defined in the request body

        [OperationContract]
        [WebInvoke(Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "Compliance/")]
        ComplianceObjectResponse ExecuteComplianceWorkflow(ComplianceObject co);

        [OperationContract]
        [WebInvoke(Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "Allocation/")]
        ServiceObjectResponse ExecuteAllocationWorkflow(ComplianceObject co);

        [OperationContract]
        [WebInvoke(Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "Placement/")]
        ServiceObjectResponse ExecutePlacementWorkflow(ComplianceObject co);
    }
}
