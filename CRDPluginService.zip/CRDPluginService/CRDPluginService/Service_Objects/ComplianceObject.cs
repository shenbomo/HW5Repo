﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace CRDPluginService
{ 
    /// <summary>
    /// This class is extended/derived from ServiceObject
    /// which holds more information specifically to ComplianceObject
    /// </summary>
    [DataContract]
    public class ComplianceObject : ServiceObject
    {
        /// <summary>
        /// Basket ID from CRD
        /// Integer
        /// </summary>
        [DataMember]
        public int basketId { get; set; }
        /// <summary>
        /// Run ID from CRD
        /// Integer
        /// </summary>
        [DataMember]
        public int runId { get; set; }
    }
}