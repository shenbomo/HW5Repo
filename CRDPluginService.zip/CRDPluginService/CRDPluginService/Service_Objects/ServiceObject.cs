﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace CRDPluginService
{
    /// <summary>
    /// ServiceObject is the parent class for handling the Service Object that has been passed into the service as defined in the request body from the client
    /// This class can be extended/derived to different types of Service Object, ComplianceObject is an example
    /// </summary>
    [DataContract]
    public class ServiceObject
    {
        /// <summary>
        /// This indicates the type of the Service Object which has been passed in
        /// Available values for now is: "COMPLIANCE"
        /// </summary>
        [DataMember]
        public String serviceObjectType { get; set; }
        /// <summary>
        /// This indicates the workflow the service should execute, defined by the client,
        /// Available values for now is: "BEFORE_PRE_TRADE", "BEFORE_POST_TRADE"
        /// </summary>
        [DataMember]
        public String workflow { get; set; }
    }
}